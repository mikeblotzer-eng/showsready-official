// ============================================================
// ShowsReady Backend — server.js
// Node.js + Express + Stripe + Anthropic AI
//
// SETUP:
//   npm install express stripe cors dotenv @anthropic-ai/sdk
//   node server.js
//
// .env file:
//   STRIPE_SECRET_KEY=sk_live_...
//   STRIPE_WEBHOOK_SECRET=whsec_...
//   ANTHROPIC_API_KEY=sk-ant-...
//   PORT=3001
//   CLIENT_URL=https://www.showsready.com
// ============================================================

require('dotenv').config();
const express   = require('express');
const stripe    = require('stripe')(process.env.STRIPE_SECRET_KEY);
const cors      = require('cors');
const Anthropic = require('@anthropic-ai/sdk');

const app       = express();
const PORT      = process.env.PORT || 3001;
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Stripe webhook MUST receive raw body — register BEFORE express.json()
app.use('/webhook', express.raw({ type: 'application/json' }));

app.use(express.json());

// ── CORS — allow your Netlify domain, www, and localhost dev
const ALLOWED = [
  'https://www.showsready.com',
  'https://showsready.com',
  'https://showsready.netlify.app',
  'http://localhost:3000',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
];
app.use(cors({
  origin: (origin, cb) => {
    // Allow requests with no origin (curl, Postman, server-to-server)
    if (!origin) return cb(null, true);
    if (ALLOWED.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,
}));

// ============================================================
// PLAN CONFIG — keep in sync with your Stripe price IDs
// ============================================================
const PLANS = {
  free: {
    name:         'Free Preview',
    price_cents:  0,
    listings:     1,
    watermark:    true,
    stripe_price: null,
    type:         'free',
  },
  single: {
    name:         'Per Listing',
    price_cents:  2999,
    listings:     1,
    watermark:    false,
    stripe_price: process.env.STRIPE_PRICE_SINGLE || 'price_1TDv7MDwB0tBPUZ7YEQ72lMx',
    type:         'payment',
  },
  pro: {
    name:         'Pro Agent',
    price_cents:  4999,
    listings:     10,
    watermark:    false,
    stripe_price: process.env.STRIPE_PRICE_PRO || 'price_1TDv8IDwB0tBPUZ7WYY9YNeR',
    type:         'subscription',
  },
  elite: {
    name:         'Elite Agent',
    price_cents:  9999,
    listings:     30,
    watermark:    false,
    stripe_price: process.env.STRIPE_PRICE_ELITE || 'price_1TDv8yDwB0tBPUZ7UGKcjzJz',
    type:         'subscription',
  },
};

// ============================================================
// USER STORE (in-memory — replace with Supabase for production)
// ============================================================
const users = new Map();

function getUser(email) {
  return users.get(email.toLowerCase()) || null;
}

function upsertUser(email, data) {
  const key      = email.toLowerCase();
  const existing = users.get(key) || {};
  const updated  = { ...existing, ...data, email: key, updatedAt: new Date().toISOString() };
  users.set(key, updated);
  return updated;
}

function newUser(email, name) {
  return upsertUser(email, {
    name,
    plan:                   'free',
    listings_used:          0,
    listings_limit:         1,
    watermark:              true,
    stripe_customer_id:     null,
    stripe_subscription_id: null,
    cancel_at_period_end:   false,
    plan_start:             new Date().toISOString(),
    plan_end:               null,
    createdAt:              new Date().toISOString(),
  });
}

function publicUser(user) {
  const { stripe_customer_id, stripe_subscription_id, ...safe } = user;
  return safe;
}

// ============================================================
// ROUTES
// ============================================================

app.get('/health', (_req, res) => {
  res.json({
    status:    'ok',
    service:   'showsready-api',
    timestamp: new Date().toISOString(),
    stripe:    !!process.env.STRIPE_SECRET_KEY,
    ai:        !!process.env.ANTHROPIC_API_KEY,
  });
});

// ─────────────────────────────────────────────────────────
// POST /api/ai
// Proxy to Anthropic — keeps the API key off the client
// Body: { prompt }
// Returns: { text }
// ─────────────────────────────────────────────────────────
app.post('/api/ai', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: 'prompt is required.' });

    const message = await anthropic.messages.create({
      model:      'claude-sonnet-4-5',
      max_tokens: 512,
      messages:   [{ role: 'user', content: prompt }],
    });

    const text = message.content
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('');

    res.json({ text });
  } catch (err) {
    console.error('[ai]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/signup
// Creates account + optionally starts a checkout session
// Body: { name, email, plan }
// ─────────────────────────────────────────────────────────
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, plan = 'free' } = req.body;
    if (!name || !email) return res.status(400).json({ error: 'name and email are required.' });

    let user = getUser(email) || newUser(email, name);

    if (plan === 'free') {
      return res.json({ success: true, user: publicUser(user) });
    }

    const session = await createCheckoutSession({ email, name, plan, user });
    res.json({ success: true, checkoutUrl: session.url });

  } catch (err) {
    console.error('[signup]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/checkout
// Creates a Stripe Checkout Session
// Body: { name, email, plan }
// Returns: { checkoutUrl, sessionId }
// ─────────────────────────────────────────────────────────
app.post('/api/checkout', async (req, res) => {
  try {
    const { name, email, plan } = req.body;

    if (!name || !email || !plan) {
      return res.status(400).json({ error: 'name, email, and plan are required.' });
    }
    if (!PLANS[plan] || plan === 'free') {
      return res.status(400).json({ error: 'Invalid plan ID.' });
    }

    const user    = getUser(email) || newUser(email, name);
    const session = await createCheckoutSession({ email, name, plan, user });

    res.json({ checkoutUrl: session.url, sessionId: session.id });

  } catch (err) {
    console.error('[checkout]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/checkout/verify?session_id=cs_...
// Called from success.html after Stripe redirects back
// Activates the user's plan and returns their state
// ─────────────────────────────────────────────────────────
app.get('/api/checkout/verify', async (req, res) => {
  try {
    const { session_id } = req.query;
    if (!session_id) return res.status(400).json({ error: 'session_id is required.' });

    const session = await stripe.checkout.sessions.retrieve(session_id);
    const email   = session.customer_details?.email || session.metadata?.email;
    const plan    = session.metadata?.plan;

    if (!email || !plan || !PLANS[plan]) {
      return res.status(400).json({ error: 'Could not determine plan from session.' });
    }

    if (session.payment_status === 'paid' || session.status === 'complete') {
      const planData = PLANS[plan];
      const now      = new Date();
      const end      = new Date(now);
      end.setDate(end.getDate() + 30);

      const user = upsertUser(email, {
        plan,
        listings_limit:         planData.listings,
        listings_used:          0,
        watermark:              planData.watermark,
        stripe_customer_id:     session.customer,
        stripe_subscription_id: session.subscription || null,
        plan_start:             now.toISOString(),
        plan_end:               planData.type === 'subscription' ? end.toISOString() : null,
        cancel_at_period_end:   false,
      });

      console.log(`[verify] Plan activated: ${email} → ${plan}`);
      return res.json({ success: true, user: publicUser(user) });
    }

    res.status(402).json({ error: 'Payment not completed.' });

  } catch (err) {
    console.error('[verify]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/user?email=...
// ─────────────────────────────────────────────────────────
app.get('/api/user', (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ error: 'email query param required.' });

  const user = getUser(email);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  res.json({ user: publicUser(user) });
});

// ─────────────────────────────────────────────────────────
// POST /api/listing/use
// Validates quota and increments usage
// ─────────────────────────────────────────────────────────
app.post('/api/listing/use', (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'email is required.' });

  const user = getUser(email);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  if (user.listings_used >= user.listings_limit) {
    return res.status(403).json({
      error:   'Listing limit reached. Please upgrade your plan.',
      upgrade: true,
      plan:    user.plan,
      used:    user.listings_used,
      limit:   user.listings_limit,
    });
  }

  const updated = upsertUser(email, { listings_used: user.listings_used + 1 });
  console.log(`[listing/use] ${email} — ${updated.listings_used}/${updated.listings_limit}`);

  res.json({
    success:   true,
    used:      updated.listings_used,
    limit:     updated.listings_limit,
    remaining: updated.listings_limit - updated.listings_used,
    watermark: updated.watermark,
  });
});

// ─────────────────────────────────────────────────────────
// POST /api/cancel
// ─────────────────────────────────────────────────────────
app.post('/api/cancel', async (req, res) => {
  try {
    const { email } = req.body;
    const user = getUser(email);

    if (!user)                        return res.status(404).json({ error: 'User not found.' });
    if (!user.stripe_subscription_id) return res.status(400).json({ error: 'No active subscription.' });

    await stripe.subscriptions.update(user.stripe_subscription_id, { cancel_at_period_end: true });
    upsertUser(email, { cancel_at_period_end: true });

    res.json({ success: true, message: 'Subscription will cancel at period end.' });

  } catch (err) {
    console.error('[cancel]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/portal
// Stripe billing portal
// ─────────────────────────────────────────────────────────
app.post('/api/portal', async (req, res) => {
  try {
    const { email } = req.body;
    const user = getUser(email);

    if (!user || !user.stripe_customer_id) {
      return res.status(404).json({ error: 'No billing account found.' });
    }

    const session = await stripe.billingPortal.sessions.create({
      customer:   user.stripe_customer_id,
      return_url: `${process.env.CLIENT_URL || 'https://www.showsready.com'}/app.html`,
    });

    res.json({ portalUrl: session.url });

  } catch (err) {
    console.error('[portal]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// STRIPE WEBHOOK
// ============================================================
app.post('/webhook', (req, res) => {
  const sig    = req.headers['stripe-signature'];
  const secret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, secret);
  } catch (err) {
    console.error('[webhook] Signature failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  console.log(`[webhook] ${event.type}`);

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const email   = session.customer_details?.email || session.metadata?.email;
      const plan    = session.metadata?.plan;

      if (email && plan && PLANS[plan]) {
        const planData = PLANS[plan];
        const now      = new Date();
        const end      = new Date(now);
        end.setDate(end.getDate() + 30);

        upsertUser(email, {
          plan,
          listings_limit:         planData.listings,
          listings_used:          0,
          watermark:              planData.watermark,
          stripe_customer_id:     session.customer,
          stripe_subscription_id: session.subscription || null,
          plan_start:             now.toISOString(),
          plan_end:               planData.type === 'subscription' ? end.toISOString() : null,
          cancel_at_period_end:   false,
        });
        console.log(`[webhook] Plan activated: ${email} → ${plan}`);
      }
      break;
    }

    case 'invoice.paid': {
      const invoice = event.data.object;
      const email   = invoice.customer_email;

      if (email) {
        const user = getUser(email);
        if (user && user.plan !== 'free' && user.plan !== 'single') {
          const now = new Date();
          const end = new Date(now);
          end.setDate(end.getDate() + 30);
          upsertUser(email, {
            listings_used:        0,
            plan_start:           now.toISOString(),
            plan_end:             end.toISOString(),
            cancel_at_period_end: false,
          });
          console.log(`[webhook] Renewed, usage reset: ${email}`);
        }
      }
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      console.warn(`[webhook] Payment failed: ${invoice.customer_email}`);
      break;
    }

    case 'customer.subscription.deleted': {
      const sub   = event.data.object;
      const cust  = await stripe.customers.retrieve(sub.customer).catch(() => null);
      const email = cust?.email || sub.metadata?.email;

      if (email) {
        upsertUser(email, {
          plan:                   'free',
          listings_limit:         1,
          listings_used:          0,
          watermark:              true,
          stripe_subscription_id: null,
          cancel_at_period_end:   false,
          plan_end:               new Date().toISOString(),
        });
        console.log(`[webhook] Downgraded to free: ${email}`);
      }
      break;
    }

    case 'payment_intent.succeeded': {
      const pi    = event.data.object;
      const email = pi.metadata?.email;
      const plan  = pi.metadata?.plan;

      if (email && plan === 'single') {
        const user = getUser(email);
        upsertUser(email, {
          plan:           'single',
          listings_limit: (user?.listings_limit || 0) + 1,
          watermark:      false,
        });
        console.log(`[webhook] Single listing credit added: ${email}`);
      }
      break;
    }

    default:
      break;
  }

  res.json({ received: true });
});

// ============================================================
// CHECKOUT SESSION FACTORY
// ============================================================
async function createCheckoutSession({ email, name, plan, user }) {
  const planData = PLANS[plan];

  let customerId = user?.stripe_customer_id;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email,
      name,
      metadata: { plan, source: 'showsready' },
    });
    customerId = customer.id;
    upsertUser(email, { stripe_customer_id: customerId, name });
  }

  const BASE_URL   = process.env.CLIENT_URL || 'https://www.showsready.com';
  const successUrl = `${BASE_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`;
  const cancelUrl  = `${BASE_URL}/pricing.html`;

  const config = {
    customer:                   customerId,
    metadata:                   { plan, email },
    success_url:                successUrl,
    cancel_url:                 cancelUrl,
    allow_promotion_codes:      true,
    billing_address_collection: 'required',
    customer_update:            { address: 'auto' },
  };

  if (planData.type === 'payment') {
    config.mode = 'payment';
    config.line_items = [{
      price_data: {
        currency:     'usd',
        unit_amount:  planData.price_cents,
        product_data: {
          name:        `ShowsReady — ${planData.name}`,
          description: '1 listing walkthrough video · No watermark · Branded end card',
        },
      },
      quantity: 1,
    }];
    // Pass email+plan in payment_intent metadata for the webhook
    config.payment_intent_data = { metadata: { plan, email } };
  } else {
    config.mode = 'subscription';
    config.line_items = [{ price: planData.stripe_price, quantity: 1 }];
    config.subscription_data = { metadata: { plan, email } };
  }

  return await stripe.checkout.sessions.create(config);
}

// ============================================================
// START
// ============================================================
app.listen(PORT, () => {
  console.log(`
  ✦ ShowsReady API
  ─────────────────────────────────
  Running on:    http://localhost:${PORT}
  Health check:  http://localhost:${PORT}/health
  Stripe key:    ${process.env.STRIPE_SECRET_KEY ? '✓ set' : '✗ MISSING'}
  Anthropic key: ${process.env.ANTHROPIC_API_KEY ? '✓ set' : '✗ MISSING — AI features disabled'}
  Webhook secret:${process.env.STRIPE_WEBHOOK_SECRET ? '✓ set' : '✗ MISSING'}
  Client URL:    ${process.env.CLIENT_URL || 'https://www.showsready.com'}
  ─────────────────────────────────
  `);
});

module.exports = app;
